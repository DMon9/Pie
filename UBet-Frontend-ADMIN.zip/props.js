
(() => {
  const API = window.CONFIG.API_BASE.replace(/\/$/, '');
  let league='nfl';
  const $=id=>document.getElementById(id);
  function row(p){ const d=document.createElement('div'); d.className='row'; d.innerHTML=`<div>${p.player} — <b>${p.market}</b> ${p.line} vs ${p.opp}</div>`; return d; }
  async function search(){ const q=$('q').value.trim(); const r=await fetch(`${API}/props/${league}/search?q=`+encodeURIComponent(q)); const j=await r.json(); const wrap=$('results'); wrap.innerHTML=''; j.forEach(p=>wrap.appendChild(row(p))); if(!j.length) wrap.textContent='No results (set SPORTRADAR_API_KEY to enable real feed).'; }
  $('pNFL').onclick=()=>{ league='nfl'; document.querySelectorAll('.chip').forEach(x=>x.classList.remove('active')); $('pNFL').classList.add('active'); search(); };
  $('pCFB').onclick=()=>{ league='cfb'; document.querySelectorAll('.chip').forEach(x=>x.classList.remove('active')); $('pCFB').classList.add('active'); search(); };
  $('searchBtn').onclick=search;
  search();
})();
