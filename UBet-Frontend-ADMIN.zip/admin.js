
(() => {
  const API = window.CONFIG.API_BASE.replace(/\/$/, '');
  const $=id=>document.getElementById(id);
  function tok(){ return localStorage.getItem('ADM_TOK')||''; }
  $('saveTok').onclick=()=>{ localStorage.setItem('ADM_TOK', $('admToken').value.trim()); alert('Saved'); };
  $('loadList').onclick=load;
  $('create').onclick=async ()=>{
    const body={ title:$('title').value, sport:$('sport').value, entry_fee:Number($('entry').value||0),
      game_id:$('game').value, market:$('market').value, selection:$('selection').value, odds:Number($('odds').value||0),
      max_entries:Number($('max').value||0), rake_pct:Number($('rake').value||0) || null, prize_split:{type:'winner-take-all'} };
    const r=await fetch(`${API}/admin/contests`,{method:'POST',headers:{'content-type':'application/json','authorization':'Bearer '+tok()},body:JSON.stringify(body)});
    if(!r.ok) return alert('Create failed'); await load(); };
  async function load(){
    const r=await fetch(`${API}/admin/contests`,{headers:{'authorization':'Bearer '+tok()}});
    if(!r.ok) return alert('Auth? set token first');
    const list=await r.json(); const wrap=$('list'); wrap.innerHTML='';
    list.forEach(c=>{
      const div=document.createElement('div'); div.className='row';
      div.innerHTML=`#${c.id} • ${c.title} • ${c.sport} • $${c.entry_fee} • ${c.status}`;
      const del=document.createElement('button'); del.textContent='Delete'; del.onclick=async()=>{ await fetch(`${API}/admin/contests/`+c.id,{method:'DELETE',headers:{'authorization':'Bearer '+tok()}}); load(); };
      wrap.append(div, del);
    });
  }
})();
