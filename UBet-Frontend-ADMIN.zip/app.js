
document.addEventListener('DOMContentLoaded',()=>{ document.querySelectorAll('.chip').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.chip').forEach(x=>x.classList.remove('active')); b.classList.add('active');})); });
